﻿namespace Plus.Communication.ConnectionManager
{
    public enum ConnectionState
    {
        OPEN = 0,
        CLOSED = 1,
        MALFUNCTIONING_PACKET = 2
    }
}